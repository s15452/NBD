import com.basho.riak.client.api.RiakClient;
import com.basho.riak.client.api.commands.kv.DeleteValue;
import com.basho.riak.client.api.commands.kv.FetchValue;
import com.basho.riak.client.api.commands.kv.StoreValue;
import com.basho.riak.client.core.RiakCluster;
import com.basho.riak.client.core.RiakNode;
import com.basho.riak.client.core.query.Location;
import com.basho.riak.client.core.query.Namespace;
import com.basho.riak.client.core.query.RiakObject;
import com.basho.riak.client.core.util.BinaryValue;

import java.util.concurrent.ExecutionException;

public class Main {
    public static void main(String [] args) throws ExecutionException, InterruptedException {

        RiakObject object = new RiakObject()
                .setContentType("application/json")
                .setValue(BinaryValue.create("{'team': 'McLaren F1 Team', 'driver': 'Lando Norris', 'number': 4}"));

        Namespace bucket = new Namespace("s15452");
        Location objectLocation = new Location(bucket, "driver8");
        StoreValue storeOp = new StoreValue.Builder(object)
                .withLocation(objectLocation)
                .build();

        RiakNode node = new RiakNode.Builder()
                .withRemoteAddress("localhost")
                .withRemotePort(8087)
                .build();
        RiakCluster cluster = new RiakCluster.Builder(node)
                .build();

        cluster.start();

        RiakClient client = new RiakClient(cluster);

        System.out.println("Dodanie ojektu");
        StoreValue.Response storeOpResp = client.execute(storeOp);

        System.out.println("Pobranie obiektu");
        FetchValue fetchOp = new FetchValue.Builder(objectLocation).build();
        RiakObject fetchedObject = client.execute(fetchOp).getValue(RiakObject.class);
        //assert(fetchedObject.getValue().equals(object.getValue()));
        System.out.println(fetchedObject.getValue());

        System.out.println("Aktualizacja obiektu");
        fetchedObject.setValue(BinaryValue.create("{'team': 'McLaren F1 Team', 'driver': 'Lando Norris', 'number': 4, 'starts': 44}"));
        StoreValue updateOp = new StoreValue.Builder(fetchedObject)
                .withLocation(objectLocation)
                .build();
        StoreValue.Response updateOpResp = client.execute(updateOp);
        updateOpResp = client.execute(updateOp);

        System.out.println("Pobranie zaktualizowanego obiektu");
        fetchOp = new FetchValue.Builder(objectLocation).build();
        fetchedObject = client.execute(fetchOp).getValue(RiakObject.class);
        //assert(fetchedObject.getValue().equals(object.getValue()));
        System.out.println(fetchedObject.getValue());

        System.out.println("Usunięcie obiektu");
        DeleteValue deleteOp = new DeleteValue.Builder(objectLocation).build();
        client.execute(deleteOp);

        System.out.println("Pobranie usuniętego obiektu");
        fetchOp = new FetchValue.Builder(objectLocation).build();
        fetchedObject = client.execute(fetchOp).getValue(RiakObject.class);
        //assert(fetchedObject.getValue().equals(object.getValue()));
        System.out.println(fetchedObject.getValue());

    }
}
